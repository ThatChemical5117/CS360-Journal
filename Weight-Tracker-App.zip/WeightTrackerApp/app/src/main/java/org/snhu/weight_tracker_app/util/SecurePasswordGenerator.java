package org.snhu.weight_tracker_app.util;

/* Author: Michael Ki
   Date: 10-15-2025

   A helper static class that generates a SecurePassword object
   from a string Uses the SecureHash class

 */


import android.util.Log;

public class SecurePasswordGenerator {
    private static String TAG = "SECUREPASSWORDGENERATOR";
    
    public static SecurePassword generate(String str) {
        // generate new salt
        String salt =  SecureHasher.generateSalt();

        // create a secure password object
        SecurePassword password = new SecurePassword();
        password.setSalt(salt);
        password.setHash(SecureHasher.generateHashWithSalt(str, salt));

        if (password.getHash() == null) {
            Log.d(TAG, "HASH IS NULL");
        }

        return password;
    }
    
}
