package org.snhu.weight_tracker_app.controller;


import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TableRow;

import org.snhu.weight_tracker_app.R;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.WeightTableModel;

public class PopupOptionsController {
    private PopupWindow mWindow;

    private final TableRow mRow;
    private final DataTableController mController;
    private final WeightTableModel mModel;

    public void inflatePopupWindow(Context context, View view) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.options_popup, null);
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;

        mWindow = new PopupWindow(layout, width, height, true);

        mWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        //layout.findViewById(R.id.options_edit_button).setOnClickListener(row -> {onPopupEditButtonClicked(context, view);});
        layout.findViewById(R.id.options_delete_button).setOnClickListener(row -> {onPopupDeleteButtonClick();});
    }

    /*
    private void onPopupEditButtonClicked(Context context, View view) {
        PopupAddWeightController addWeightController = new PopupAddWeightController(mController, mModel);
        addWeightController.setOptionGetWeight(true);
        addWeightController.setWeight(mController.getWeightFromRow(mRow));

        mRow.setVisibility(View.GONE);

        mWindow.dismiss();
        inflatePopupWindow(context,view);
    }
     */

    private void onPopupDeleteButtonClick() {
        mRow.setVisibility(View.GONE);
        Weight weight = mController.getWeightFromRow(mRow);
        weight.setAccountId(mModel.getAccountId());
        mModel.deleteWeight(weight);

        mWindow.dismiss();
    }

    public PopupOptionsController(DataTableController controller, WeightTableModel model, TableRow row) {
        mController = controller;
        mModel = model;
        mRow = row;
    }
}