package org.snhu.weight_tracker_app.model.Repo;

import android.content.Context;

import androidx.room.Room;

import org.snhu.weight_tracker_app.model.Repo.Account.Account;
import org.snhu.weight_tracker_app.model.Repo.Account.AccountDao;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.Repo.Weight.WeightDao;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeightTrackerRepository {

    // Private static
    private static WeightTrackerRepository mWeightRepo;
    private static final int NUMBER_OF_THREADS = 4;
    private static final ExecutorService mDatabaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    public static WeightTrackerRepository getInstance(Context context) {
        if (mWeightRepo == null) {
            mWeightRepo = new WeightTrackerRepository(context);
        }
        return mWeightRepo;
    }

    // Private
    private final WeightDao mWeightDao;
    private final AccountDao mAccountDao;

    private WeightTrackerRepository(Context context) {
        WeightTrackerDatabase database = Room.databaseBuilder(context, WeightTrackerDatabase.class, "weight.db")
                .fallbackToDestructiveMigration(true)
                .build();

        mWeightDao = database.weightDao();
        mAccountDao = database.accountDao();
    }

    // Callable implementations
    private class CallableAccount implements Callable<Account> {
        private final String mUsername;

        public CallableAccount(String username) {
            mUsername = username;
        }

        @Override
        public Account call() {
            return mAccountDao.getAccount(mUsername);
        }
    }

    private class CallableListWeight implements Callable<List<Weight>> {
        private final long mAccount_id;

        public CallableListWeight(long account_id) {
            mAccount_id = account_id;
        }

        @Override
        public List<Weight> call() {
            return mWeightDao.getWeights(mAccount_id);
        }
    }


    private class CallableWeight implements Callable<Weight> {
        private final long mId;

        public CallableWeight(long id) {
            mId = id;
        }

        @Override
        public Weight call() {
            return mWeightDao.getWeight(mId);
        }
    }

    // Public --- Weight
    public Weight getWeight(long id) {
        final Future<Weight> weightFuture = mDatabaseExecutor.submit(new CallableWeight(id));

        try {
            return weightFuture.get();
        } catch (Exception e) {
            return null;
        }
    }

    public List<Weight> getWeights(long accountId) {
        final Future<List<Weight>> weightsFuture = mDatabaseExecutor.submit(new CallableListWeight(accountId));

        try {
            return weightsFuture.get();
        } catch (Exception e) {
            return null;
        }
    }

    public void addWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> {
            long accountID = mWeightDao.addWeight(weight);
            weight.setId(accountID);

        });
    }

    public void updateWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> {
            mWeightDao.updateWeight(weight);
        });
    }

    public void deleteWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> {
            mWeightDao.deleteWeight(weight);
        });
    }


    // Public --- Account access methods
    public void addAccount(Account account) {
        mDatabaseExecutor.execute(() -> {
            long accountId = mAccountDao.addAccount(account);
            account.setId(accountId);
        });

    }

    // get account, uses the CallableAccount class to get the result from the thread
    public Account getAccount(String username) {

        // We wait for a result from the DB
        final Future<Account> accountFuture = mDatabaseExecutor.submit(new CallableAccount(username));

        // return the result from the database
        // On DB error return null
        try {
            return accountFuture.get();
        } catch (Exception e) {
            return null;
        }
    }

    // U and D methods
    public void deleteAccount(Account account) {
        mDatabaseExecutor.execute(() -> {
            mAccountDao.deleteAccount(account);
        });

    }

    public void updateAccount(Account account) {
        mDatabaseExecutor.execute(() -> {
            mAccountDao.updateAccount(account);
        });
    }
}