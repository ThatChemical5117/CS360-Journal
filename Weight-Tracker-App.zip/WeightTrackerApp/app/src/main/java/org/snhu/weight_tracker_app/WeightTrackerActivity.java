package org.snhu.weight_tracker_app;
/* Author: Michael Kik
   Date: 10-17-15

   Model for the table
   provides and stores the table state

   pull from the Goal and Weight databases
 */

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.snhu.weight_tracker_app.controller.PopupAddWeightController;
import org.snhu.weight_tracker_app.model.Repo.Account.Account;
import org.snhu.weight_tracker_app.model.WeightTableModel;
import org.snhu.weight_tracker_app.controller.DataTableController;

import java.text.BreakIterator;

public class WeightTrackerActivity extends AppCompatActivity {
    private static final String TAG = "weight_tracker.WeightTrackerActivity";
    public static final String EXTRA_ACCOUNT = "org.snhu.weight_tracker_app.username";
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    private static final int MY_PERMISSIONS_REQUEST_READ_PHONE_STATE = 0;
    private DataTableController mTableController;
    private WeightTableModel mTableModel;

    private String mPhoneNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        // pull the account from the intents
        Account mAccount = (Account) getIntent().getSerializableExtra(EXTRA_ACCOUNT);

        // account should not be null
        if (mAccount == null) { throw new RuntimeException("Account is null, when it should be filled"); }
        setTitle(mAccount.getUsername());

        // create a new table controller
        mTableController = new DataTableController(findViewById(R.id.table));

        // Create a new TableModel
        mTableModel = new WeightTableModel(getApplicationContext(), mAccount.getId(), this);

        // Fill new table
        mTableController.inflateHeader(getApplicationContext());
        mTableController.fillTable(getApplicationContext(), mTableModel);

        //mTableController.inflateTable();
        // set the listener for the add weight button
        findViewById(R.id.tracker_add_weight_button).setOnClickListener(this::onAddWeightButtonClick);

        getPhoneNumber();

    }

    @SuppressLint("HardwareIds")
    public void getPhoneNumber() {
        TelephonyManager tMgr = (TelephonyManager)getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE},
                    MY_PERMISSIONS_REQUEST_READ_PHONE_STATE);
        } else {
            mPhoneNumber = tMgr.getLine1Number();
        }
    }

    public void sendSms(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(mPhoneNumber, null, message, null, null);
        }
    }


    // On click of the add weight button
    private void onAddWeightButtonClick(View view) {
        try {
            // open the popup
            PopupAddWeightController popupController = new PopupAddWeightController(mTableController, mTableModel);
            popupController.inflatePopupWindow(getApplicationContext(), view);
        } catch (Exception e) {
            Log.d(TAG, "Something went wrong with Popup window"); // DEBUG
        }

    }

}

