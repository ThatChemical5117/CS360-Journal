package org.snhu.weight_tracker_app.util;
/* Author: Michael Kik
   Name: SecurePasswordHasher.java
   Date: 10-09-2025
   Course: CS-360

   Static util class to simplify the creation of hash and salts
   when using the SecurePassword class

 */

// Imports
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class SecureHasher {

    private final static SecureRandom random = new SecureRandom();
    private SecureHasher() {};

    private static byte[] decodeBase64(String dataToDecode) {
        return Base64.decode(dataToDecode, Base64.DEFAULT);
    }

    private static String encodeBase64(byte[] dataToEncode) {
        return Base64.encodeToString(dataToEncode, Base64.DEFAULT);
    }

    @NonNull
    public static String generateSalt() {
        byte[] salt = new byte[16];
        random.nextBytes(salt);

        return encodeBase64(salt);
    }

    @Nullable
    public static String generateHashWithSalt(@NonNull String password, String salt) {
        KeySpec spec = new PBEKeySpec(password.toCharArray(), decodeBase64(salt), 65536, 256);
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            // Convert the bytes into a string for easy use in the program
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return new String(Base64.decode(hash, Base64.DEFAULT));
        } catch (Exception e) {
            return null;
        }
    }
}
