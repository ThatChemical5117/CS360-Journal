package org.snhu.weight_tracker_app.controller;

/* Author: Michael Kik
   Date: 10-17-2025

   This controller represents the popup window that is used
   to add new data to the table, this object takes in a TableController object
   to push changes to the view, and model

*/

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import org.snhu.weight_tracker_app.R;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.WeightTableModel;

public class PopupAddWeightController {
    private PopupWindow mWindow;
    private final DataTableController mController;
    private final WeightTableModel mModel;

    private boolean mPullWeightFromValues = false;

    private Weight mWeight;


    
    public void inflatePopupWindow(Context context, View view) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.add_weight_popup, null);
        
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true;
        
        mWindow = new PopupWindow(layout, width, height, focusable);
        
        mWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        if (mPullWeightFromValues) {
            loadIntoValues(layout, mWeight);
        }

        layout.findViewById(R.id.popup_button).setOnClickListener((viewWidget) -> {onPopupButtonClicked(context, layout);});
        
    }

    private void loadIntoValues(LinearLayout view, Weight weight) {
        ((TextView)view.findViewById(R.id.popup_date_input)).setText(weight.getDate());
        ((TextView)view.findViewById(R.id.popup_weight_input)).setText(weight.getDate());
        ((CheckBox)view.findViewById(R.id.popup_set_goal_input)).setChecked(weight.getIsGoal());
    }

    private Weight createNewWeight(LinearLayout view) {
        String date = ((TextView)view.findViewById(R.id.popup_date_input)).getText().toString();
        int weightAmount = Integer.parseInt(((TextView)view.findViewById(R.id.popup_weight_input)).getText().toString());
        boolean isGoal = ((CheckBox)view.findViewById(R.id.popup_set_goal_input)).isChecked();

        Weight weight = new Weight();

        weight.setDate(date);
        weight.setWeight(weightAmount);
        weight.setIsGoal(isGoal);
        weight.setIsCompleted(false);

        return weight;
    }
    
    private void onPopupButtonClicked(Context context, LinearLayout view) {

        Weight weight = createNewWeight(view);

        // Instead of pushing the changes to the model
        // We use this to change the values in a different
        if (mPullWeightFromValues) {
            mWeight = weight;

            mModel.updateWeight(weight);
            mController.addToTable(mController.generateTableRow(context, weight), weight.getIsGoal());
            return;
        }

        mModel.addWeight(weight);
        mController.addToTable(mController.generateTableRow(context, weight), weight.getIsGoal());

        mWindow.dismiss();
    }
    
    public PopupAddWeightController(DataTableController controller, WeightTableModel model) {
        mController = controller;
        mModel = model;
    }

    public void setWeight(Weight weight) {
        mWeight = weight;
    }

    public void setOptionGetWeight(boolean optionGetWeight) {
        mPullWeightFromValues = optionGetWeight;
    }

    public Weight getWeight() {
        return mWeight;
    }
}
