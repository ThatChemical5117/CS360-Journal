package org.snhu.weight_tracker_app.model;
/* Author: Michael
   Date: 10-09-2025

   Basic class to represent the login information that comes
   in through the view. The edit text objects are used to get the values
   from the user

 */

import android.widget.EditText;

public class LoginInfo {
    String mUsername;
    String mPassword;

    public LoginInfo(EditText usernameEditText, EditText passwordEditText) {
        mUsername = usernameEditText.getText().toString();
        mPassword = passwordEditText.getText().toString();
    }

    public String getUsername() {
        return mUsername;
    }

    public String getPassword() {
        return mPassword;
    }

    public boolean isFieldsEmpty() {
        return mUsername.isEmpty() || mPassword.isEmpty();
    }
}
