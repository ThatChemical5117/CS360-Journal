package org.snhu.weight_tracker_app.model.Repo.Weight;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
import java.util.UUID;

@Dao
public interface WeightDao  {

    @Query("SELECT * from Weight WHERE id = :id")
    Weight getWeight(long id);

    @Query("SELECT * from Weight WHERE account_id = :accountId")
    List<Weight> getWeights(long accountId);

    @Insert
    long addWeight(Weight weight);

    @Delete
    void deleteWeight(Weight weight);

    @Update
    void updateWeight(Weight weight);

}
