package org.snhu.weight_tracker_app.model.Repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import org.snhu.weight_tracker_app.model.Repo.Account.Account;
import org.snhu.weight_tracker_app.model.Repo.Account.AccountDao;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.Repo.Weight.WeightDao;

@Database(entities = {Account.class, Weight.class}, version = 4)
public abstract class WeightTrackerDatabase extends RoomDatabase {
    public abstract AccountDao accountDao();
    public abstract WeightDao weightDao();

}
