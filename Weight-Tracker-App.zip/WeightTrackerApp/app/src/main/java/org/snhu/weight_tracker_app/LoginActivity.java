package org.snhu.weight_tracker_app;
/* Author: Michael Kik
   Date: October 6th, 2025
   Course: CS-360

   Controller implementation
   activity_login(View)
   LoginManager(Model)

   Pulls from the view and updates the model accordingly to
   provide login functionality to the page.

   Sends an account object through an intent
 */

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.widget.EditText;
import android.content.Intent;
import android.view.View;

import org.snhu.weight_tracker_app.model.LoginInfo;
import org.snhu.weight_tracker_app.model.LoginModel;

public class LoginActivity extends AppCompatActivity {
    // Tag for Log
    private final static String TAG = "org.snhu.weight_tracker_app.LoginActivity";

    // LoginManager model
    private LoginModel m_LoginModel;

    // Edit text
    private EditText m_UsernameEditText;
    private EditText m_PasswordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Get edit text fields
        m_UsernameEditText = findViewById(R.id.edit_username);
        m_PasswordEditText = findViewById(R.id.edit_password);

        // Set listeners
        findViewById(R.id.login_button).setOnClickListener(this::onLogin);
        findViewById(R.id.signup_button).setOnClickListener(this::onSignUp);

        // Init LoginManager
        m_LoginModel = new LoginModel(getApplicationContext());
    }

    // Change the view to display that there was an error visually
    private void onError(String message) {
        // TODO: Change the view to reflect a improper login/signup attempt
        Log.e(TAG, message);
    }

    // Login button callback
    public void onLogin(View view) {

        LoginInfo info = new LoginInfo(m_UsernameEditText, m_PasswordEditText);

        // Don't proceed if the info is not filled out
        if (info.isFieldsEmpty()) {
            onError("Username or password field is empty");
            return;
        }

        // if the login manager succeed we should move to the next page
        if (m_LoginModel.validateLogin(info)) {
            Intent intent = new Intent(LoginActivity.this, WeightTrackerActivity.class);
            intent.putExtra(WeightTrackerActivity.EXTRA_ACCOUNT, m_LoginModel.getAccount());
            startActivity(intent);
        } else {
            onError("Incorrect username or password");
        }
    }

    // Sign up button callback
    public void onSignUp(View view) {
        // same as above
        LoginInfo info = new LoginInfo(m_UsernameEditText, m_PasswordEditText);

        // Don't proceed if the info is not filled out
        if (info.isFieldsEmpty()) {
            onError("Username or password field is empty");
            return;
        }

        if (m_LoginModel.createAccount(info)) {
            Intent intent = new Intent(LoginActivity.this, WeightTrackerActivity.class);
            intent.putExtra(WeightTrackerActivity.EXTRA_ACCOUNT, m_LoginModel.getAccount());
            startActivity(intent);
        } else {
            onError("Something went wrong, please try again");
        }

    }
}