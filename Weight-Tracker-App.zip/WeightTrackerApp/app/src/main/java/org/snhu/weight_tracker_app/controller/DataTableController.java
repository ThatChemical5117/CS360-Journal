package org.snhu.weight_tracker_app.controller;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.snhu.weight_tracker_app.R;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.WeightTableModel;

import java.util.List;

public class DataTableController {
    private int mGoalRowsCount = 0;
    private final TableLayout mTableView;

    private void onOptionsClick(Context context, WeightTableModel model, View row) {
        PopupOptionsController popupOptionsController = new PopupOptionsController(this, model, (TableRow)row);

        popupOptionsController.inflatePopupWindow(context, row);
    }

    public TableRow generateTableRow(Context context, Weight weight) {
        TableRow row = (TableRow) LayoutInflater.from(context).inflate(R.layout.attrib_table_weight, null);

        ((TextView)row.findViewById(R.id.row_weight_key)).setText(String.valueOf(weight.getId()));
        ((TextView)row.findViewById(R.id.row_date)).setText(weight.getDate());
        ((TextView)row.findViewById(R.id.row_weight)).setText(String.valueOf(weight.getWeight()));


        // Set visibility
        if (!weight.getIsGoal()) {
            row.findViewById(R.id.row_goal_in_progress).setVisibility(View.GONE);
            row.findViewById(R.id.row_goal_completed).setVisibility(View.INVISIBLE);
            return row;
        }


        // if the weight is a goal set appropriate visibility
        if (weight.getIsCompleted()) {
            row.findViewById(R.id.row_goal_completed).setVisibility(View.VISIBLE);
            row.findViewById(R.id.row_goal_in_progress).setVisibility(View.GONE);
        } else {
            row.findViewById(R.id.row_goal_in_progress).setVisibility(View.VISIBLE);
            row.findViewById(R.id.row_goal_completed).setVisibility(View.GONE);
        }

        return row;
    }

    public void setTableRowListener(TableRow row, View.OnClickListener listener) {
        row.findViewById(R.id.row_options_button).setOnClickListener(listener);
    }

    public void addToTable(TableRow row, boolean isGoal) {
        if (isGoal) {
            mGoalRowsCount++;
            mTableView.addView(row, 1);
            return;
        }

        mTableView.addView(row, mGoalRowsCount + 1);
    }

    public DataTableController(TableLayout tableView) {
        mTableView = tableView;
    }

    public void fillTable(Context context, WeightTableModel model) {
        List<Weight> list = model.getWeightList();

        if (list.isEmpty()) {
            TableRow row = (TableRow) LayoutInflater.from(context).inflate(R.layout.attrib_table_weight, null);
            row.setVisibility(View.INVISIBLE);
            addToTable(row, false);
        }

        for (Weight weight:list) {
            TableRow row = generateTableRow(context, weight);
            setTableRowListener(row, view -> {onOptionsClick(context, model, row);});
            addToTable(row, weight.getIsGoal());
        }
    }

    private String getFromTextView(TableRow row, int id) {
        return ((TextView)row.findViewById(id)).getText().toString();
    }

    private boolean isRowGoal(TableRow row) {
        return row.findViewById(R.id.row_goal_completed).getVisibility() == View.VISIBLE || row.findViewById(R.id.row_goal_in_progress).getVisibility() == View.VISIBLE;
    }

    private boolean isCompleted(TableRow row) {
        return row.findViewById(R.id.row_goal_completed).getVisibility() == View.VISIBLE;
    }

    public Weight getWeightFromRow(TableRow row) {

        long id = Long.parseLong(getFromTextView(row, R.id.row_weight_key));
        String date = getFromTextView(row, R.id.row_date);
        int weightAmount = Integer.parseInt(getFromTextView(row, R.id.row_weight));

        Weight weight = new Weight();

        weight.setId(id);
        weight.setDate(date);
        weight.setWeight(weightAmount);
        weight.setIsGoal(isRowGoal(row));
        weight.setIsCompleted(isCompleted(row));

        return weight;
    }

    public void inflateHeader(Context context) {
        TableRow header = (TableRow) LayoutInflater.from(context).inflate(R.layout.attrib_table_header, null);
        mTableView.addView(header, 0);
    }

}