package org.snhu.weight_tracker_app.model.Repo.Account;
/* Author: Michael Kik
   Date: 10-10-25

   Data access object for Account
 */


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface AccountDao {
    @Query("SELECT * FROM Account WHERE username = :username")
    Account getAccount(String username);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addAccount(Account account);

    @Update
    void updateAccount(Account account);

    @Delete
    void deleteAccount(Account account);
}
