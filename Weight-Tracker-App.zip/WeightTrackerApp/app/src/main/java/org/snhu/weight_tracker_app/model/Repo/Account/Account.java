package org.snhu.weight_tracker_app.model.Repo.Account;
/* Author: Michael Kik
   Name: Account.java
   Course: CS-360
   Date: 10-10-25

   Entity used to represent an Account
   also implements Serializable so it can be passed through intents

 */

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import org.snhu.weight_tracker_app.util.SecurePassword;

import java.io.Serializable;

@Entity()
public class Account implements Serializable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name ="id")
    private long mId;

    @ColumnInfo(name = "username")
    private String mUsername;

    @ColumnInfo(name = "hash")
    private String mHash;

    @ColumnInfo(name = "salt")
    private String mSalt;


    // Getters
    public void setId(Long id)  { mId = id; }
    public void setUsername(String username) { mUsername = username; }
    public void setHash(String hash) { mHash = hash; }
    public void setSalt(String salt) { mSalt = salt; }

    // Setters
    public long getId() { return mId; }
    public String getUsername() { return mUsername; }
    public String getHash() { return mHash; }
    public String getSalt() { return mSalt; }

    // Set the password using a SecurePassword object
    public void setPassword(SecurePassword password) {
        mHash = password.getHash();
        mSalt = password.getSalt();
    }

    // Get the password as a SecurePassword object
    public SecurePassword getPassword() {
        return new SecurePassword()
                .setSalt(mSalt)
                .setHash(mHash);
    }

    /* Note: For testing
    public boolean isEmpty() {
        return (mUsername == null);
    }
     */
}
