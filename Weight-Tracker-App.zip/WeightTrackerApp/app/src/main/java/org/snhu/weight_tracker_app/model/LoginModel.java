package org.snhu.weight_tracker_app.model;
/* Author: Michael Kik
   Date: 10-09-2025

   Login manager acts as the login page main model
   The class controls the other classes to write and read from the database
   as well as validate user credentials
 */


import android.content.Context;

import org.snhu.weight_tracker_app.model.Repo.Account.Account;
import org.snhu.weight_tracker_app.model.Repo.WeightTrackerRepository;
import org.snhu.weight_tracker_app.util.SecurePasswordGenerator;

public class LoginModel {
    private static final String TAG = "org.snhu.weight_tracker_app.LoginManager"; // For debug
    WeightTrackerRepository mRepo;
    Account mAccount;

    public LoginModel(Context context) {
        mRepo = WeightTrackerRepository.getInstance(context);
        mAccount = null;
    }

    public boolean createAccount(LoginInfo info) {
        // pull account from DB
        Account accountFromDB = mRepo.getAccount(info.getUsername());

        // return if there is an existing account
        if (accountFromDB != null) return false;

        // create a new account
        Account account = new Account();
        account.setUsername(info.getUsername());
        account.setPassword(SecurePasswordGenerator.generate(info.getPassword()));

        //add a new account to the repo
        mRepo.addAccount(account);

        mAccount = account;
        return true;
    }

    public boolean validateLogin(LoginInfo info) {
        // check that user exists
        Account account = mRepo.getAccount(info.getUsername());

        // Guard clauses
        if (account == null ) return false;
        if (!account.getPassword().equals(info.getPassword())) return false;

        // set the account
        mAccount = account;
        return true;
    }

    public Account getAccount() {
        return mAccount;
    }
}
