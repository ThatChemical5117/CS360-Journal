package org.snhu.weight_tracker_app.util;
/* Author: Michael Kik
   Name: SecurePassword.java
   Date: 10-09-2025
   Course: CS-360

   Secure password represents a hash and salt used for
   passwords, also provides a simple function to check if a string
   is equivalent to the hash held by this object

 */
public class SecurePassword {
    private String mHash;
    private String mSalt;

    public SecurePassword setHash(String hash) {
        mHash = hash;
        return this;
    }

    public SecurePassword setSalt(String salt) {
        mSalt = salt;
        return this;
    }

    public String getHash() {
        return mHash;
    }

    public String getSalt() {
        return mSalt;
    }

    public boolean equals(String str) {
        return mHash.equals(SecureHasher.generateHashWithSalt(str, mSalt));
    }
}



