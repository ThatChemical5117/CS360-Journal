package org.snhu.weight_tracker_app.model;
/* Author: Michael Kik
   Date: 10-15-2025

   Model representing a weight table, provides methods to update and change the table

 */

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.snhu.weight_tracker_app.WeightTrackerActivity;
import org.snhu.weight_tracker_app.model.Repo.Weight.Weight;
import org.snhu.weight_tracker_app.model.Repo.WeightTrackerRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class WeightTableModel {
    // DEBUG
    private final String TAG = "weight_tracker.datamodel";
    private final WeightTrackerRepository mWeightTrackerRepo;
    private final WeightTrackerActivity mActivity;

    private static String mPhoneNumber;
    public long mAccountId;
    private Weight currentTarget;

    public WeightTableModel(Context context, long accountId, WeightTrackerActivity activity) {
        mWeightTrackerRepo = WeightTrackerRepository.getInstance(context);
        mAccountId = accountId;
        mActivity = activity;
    }

    public List<Weight> getWeightList() {
        List<Weight> weightList = mWeightTrackerRepo.getWeights(mAccountId);

        if (weightList == null) {
            weightList = new ArrayList<Weight>();
        }

        for (Weight weight: weightList) {
            if (weight.getIsGoal()) {
                if (currentTarget != null) {
                    if (weight.getWeight() > currentTarget.getWeight()) {
                        currentTarget = weight;
                    }
                } else {
                    currentTarget = weight;
                }
            } else {
                if (currentTarget.getWeight() <= weight.getWeight()) {
                    mActivity.sendSms("Goal Reached");

                    currentTarget.setIsCompleted(true);
                    currentTarget = null;
                }
            }
        }

        return weightList;
    }



    public void addWeight(Weight weight) {
        weight.setAccountId(mAccountId);
        mWeightTrackerRepo.addWeight(weight);
    }

    public void updateWeight(Weight weight) {
        weight.setAccountId(mAccountId);
        mWeightTrackerRepo.updateWeight(weight);
    }

    public void deleteWeight(Weight weight) {

        mWeightTrackerRepo.deleteWeight(weight);

    }

    public long getAccountId() {
        return mAccountId;
    }

    public void setPhoneNumber(String phoneNumber) {
        mPhoneNumber = phoneNumber;
    }
}