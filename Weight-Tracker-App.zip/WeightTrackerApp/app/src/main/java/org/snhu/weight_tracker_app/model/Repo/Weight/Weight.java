package org.snhu.weight_tracker_app.model.Repo.Weight;

import static androidx.room.ForeignKey.CASCADE;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import org.snhu.weight_tracker_app.model.Repo.Account.Account;

import java.util.UUID;

@Entity(foreignKeys = @ForeignKey(entity = Account.class, parentColumns = "id",
childColumns = "account_id", onDelete = CASCADE))
public class Weight {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="id")
    private long mId;

    @ColumnInfo(name ="date")
    private String mDate;

    @ColumnInfo(name = "weight")
    private int mWeight;

    @ColumnInfo(name = "isGoal")
    private boolean mIsGoal;

    @ColumnInfo(name = "isCompleted")
    private boolean mIsCompleted;

    @ColumnInfo(name="account_id")
    private long mAccountId;

    // Setters
    public void setId(long id) { mId = id; }

    public void setDate(String date) { mDate = date; }

    public void setWeight(int weight) { mWeight = weight; }

    public void setAccountId(long id) { mAccountId = id;}

    public void setIsGoal(boolean isGoal) { mIsGoal = isGoal; }

    public void setIsCompleted(boolean isCompleted) {mIsCompleted = isCompleted;}

    // Getters
    public long getId() { return mId; }

    public String getDate() { return mDate; }

    public int getWeight() { return mWeight; }

    public long getAccountId() {return mAccountId;}

    public boolean getIsGoal() { return mIsGoal;}

    public boolean getIsCompleted() { return mIsCompleted;}
}
